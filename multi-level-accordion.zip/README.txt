A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/PjdbQw.

 Flat design accordion with as many nested levels as you need.  Click on it!